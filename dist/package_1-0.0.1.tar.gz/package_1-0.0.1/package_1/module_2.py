def update_address (customer, new_address):
    customer.address = new_address
    print(f"El domicilio de {customer.name} {customer.last_name} se ha actualizado a: {customer.address}")
    



