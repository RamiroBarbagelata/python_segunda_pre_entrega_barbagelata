from setuptools import setup

setup(
    name="package_1",
    version="0.0.1",
    description="Segunda pre entrega Python",
    author="Ramiro Barbagelata",
    author_email="ramirobarbagelata@gmail.com",
    packages=["package_1"],
)

